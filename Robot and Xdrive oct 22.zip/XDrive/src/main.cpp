/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       henryzhao                                                 */
/*    Created:      Fri Aug 28 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// DriveFL              motor         1               
// DriveFR              motor         2               
// DriveBL              motor         3               
// Lift                 motor         7               
// Intake1              motor         5               
// Intake2              motor         6               
// Viss                 vision        11              
// Discarder            motor         9               
// DriveBR              motor         4               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;
competition Competition;

# define mPi 3.14159265358979323846;

int driveThreshold = 10;
int turnThreshold = 10;

float liftAccelVal = 200;
float liftAccelSpeed = 0.0006;

float slowMult = 0.8;
float normMult = 1.9;
float multiplier = normMult;

bool slowmode = false;
int isBlue = -1;

int controlAxis (int axis){
  switch(axis){
    case 1: {
      return Controller1.Axis1.position();
    }
    case 2: {
      return Controller1.Axis2.position();
    }
    case 3: {
      return Controller1.Axis3.position();
    }
    case 4: {
      return Controller1.Axis4.position();
    }

    default:
      return 0;
  }
}

bool controlButton (char button, bool top = false){
  switch(button){
    case 'A':{
      return Controller1.ButtonA.pressing();
    }
    case 'B':{
      return Controller1.ButtonB.pressing();
    }
    case 'X':{
      return Controller1.ButtonX.pressing();
    }
    case 'Y':{
      return Controller1.ButtonY.pressing();
    }

    case 'U':{
      return Controller1.ButtonUp.pressing();
    }
    case 'D':{
      return Controller1.ButtonDown.pressing();
    }
    case 'L':{
      return Controller1.ButtonLeft.pressing();
    }
    case 'R':{
      return Controller1.ButtonRight.pressing();
    }

    case 'l':{
      if(top) return Controller1.ButtonL1.pressing();
      else return Controller1.ButtonL2.pressing();
    }
    case 'r':{
      if(top) return Controller1.ButtonR1.pressing();
      else return Controller1.ButtonR2.pressing();
    }

    default:
      return false;
  }
}

void stopDrive(int motorr){
  //stops driving

  switch(motorr){
    case 1: DriveFL.stop();
    case 2: DriveFR.stop();
    case 3: DriveBL.stop();
    case 4: DriveBR.stop();
  }
}

double roundd(double d)
{
    return floor(d + 0.5);
}

float map (float val, float inMin, float inMax, float outMin,float outMax) {
  double slope = 1.0 * (inMax - inMin) / (outMax - outMin);
  float output = inMin + roundd(slope * (val - inMin));

  return output;
}

void drive(int speed1, int speed2, int speed3, int speed4){
  //drive the robot with speed 1, 2, 3, & 4

  // int max = std::max(std::max(speed1, speed2),std::max(speed3, speed4));
  // int min = std::min(std::min(speed1, speed2),std::min(speed3, speed4));

  // float res1 = map(speed1, min, max, -100, 100);
  // float res2 = map(speed2, min, max, -100, 100);
  // float res3 = map(speed3, min, max, -100, 100);
  // float res4 = map(speed4, min, max, -100, 100);

  float res1 = fmax(fmin(speed1, 100),-100);
  float res2 = fmax(fmin(speed2, 100),-100);
  float res3 = fmax(fmin(speed3, 100),-100);
  float res4 = fmax(fmin(speed4, 100),-100);

  if(speed1 == 0) stopDrive(1);
  else DriveFL.spin(vex::directionType::fwd,res1 * multiplier,vex::velocityUnits::rpm);
  
  if(speed2 == 0) stopDrive(2);
  else DriveFR.spin(vex::directionType::fwd,res2 * multiplier,vex::velocityUnits::rpm);

  if(speed3 == 0) stopDrive(3);
  else DriveBL.spin(vex::directionType::fwd,res3 * multiplier,vex::velocityUnits::rpm);

  if(speed4 == 0) stopDrive(4);
  else DriveBR.spin(vex::directionType::fwd,res4 * multiplier,vex::velocityUnits::rpm);
}

void initialize () {
  int origRed1[] = {10,10}; 
  int origBlue1[] = {270,10}; 

  Viss.setLedMode(vex::vision::ledMode::manual);
  Viss.setLedBrightness(100);

  int size[] = {200,100};

  Brain.Screen.setPenColor("#ff3700");
  Brain.Screen.drawRectangle(origRed1[0], origRed1[1], size[0], size[1], "#8c1e00");

  Brain.Screen.setPenColor("#00b7ff");
  Brain.Screen.drawRectangle(origBlue1[0], origBlue1[1], size[0], size[1], "#00719e");

  while(true){
    if(Brain.Screen.pressing() || controlButton('X') || controlButton('Y')){
      int X = Brain.Screen.xPosition();//X pos of press
      int Y = Brain.Screen.yPosition();// Y pos of press

      //Checks if press is within boundaries of rectangle
      if (((X >= origRed1[0] && X <= origRed1[0] + size[0]) && (Y >= origRed1[1] && Y <= origRed1[1] + size[1])) || controlButton('X')){
        Brain.Screen.drawRectangle(0, 0, 500, 500, "#8c1e00");
        isBlue = 0;
        break;
      }

      if (((X >= origBlue1[0] && X <= origBlue1[0] + size[0]) && (Y >= origBlue1[1] && Y <= origBlue1[1] + size[1])) || controlButton('Y')){
        Brain.Screen.drawRectangle(0, 0, 500, 500, "#00719e");
        isBlue = 1;
        break;
      }
    }
  }
}

void driveLoop () {

  int driveAms[] = {0,0,0,0};

  if(controlAxis(3) > driveThreshold || controlAxis(3) < -driveThreshold){
    driveAms[0] += controlAxis(3);
    driveAms[1] += controlAxis(3);
    driveAms[2] += controlAxis(3);
    driveAms[3] += controlAxis(3);
  }

  if(controlAxis(1) > turnThreshold || controlAxis(1) < -turnThreshold){
    driveAms[0] += controlAxis(1);
    driveAms[1] -= controlAxis(1);
    driveAms[2] += controlAxis(1);
    driveAms[3] -= controlAxis(1);
  }

  if(controlAxis(4) > turnThreshold || controlAxis(4) < -turnThreshold){
    driveAms[0] += controlAxis(4);
    driveAms[1] -= controlAxis(4);
    driveAms[2] -= controlAxis(4);
    driveAms[3] += controlAxis(4);
  }

  drive(driveAms[0],driveAms[1],driveAms[2],driveAms[3]);

  bool revDisc = false;
  if(controlButton('U')) revDisc = true;

  Viss.takeSnapshot(Viss__BLUE_BALL);
  if(Viss.objectCount > 0) {
    if(isBlue == 0){
      revDisc = true;
    }
    Viss.setLedColor(0, 0, 255);
  }else {
    Viss.takeSnapshot(Viss__RED_BALL);
    if(Viss.objectCount > 0) {
      if(isBlue == 1){
        revDisc = true;
      }
      Viss.setLedColor(255, 0, 0);
    }else {
      Viss.setLedColor(255, 255, 255);
    }
  }

  //Viss.setLedColor(255, 255, 255);

  if(controlButton('l', true)){
    Lift.spin(vex::directionType::fwd,fmin(liftAccelVal, 200),vex::velocityUnits::rpm);
    Discarder.spin(vex::directionType::fwd,(revDisc? -1:1) * fmin(liftAccelVal, 200),vex::velocityUnits::rpm);
    if(liftAccelVal < 200) liftAccelVal += liftAccelSpeed;
  }else if(controlButton('l', false)){
    Lift.spin(vex::directionType::fwd,-fmin(liftAccelVal, 200),vex::velocityUnits::rpm);
    Discarder.spin(vex::directionType::fwd,(revDisc? 1:-1) * fmin(liftAccelVal, 200),vex::velocityUnits::rpm);
    if(liftAccelVal < 200) liftAccelVal += liftAccelSpeed;
  }else {
    Lift.stop();
    Discarder.stop();

    liftAccelVal = 200;
  }

  if(controlButton('r', true)){
    Intake1.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm);
    Intake2.spin(vex::directionType::fwd,200,vex::velocityUnits::rpm);

  }else if(controlButton('r', false)){
    Intake1.spin(vex::directionType::fwd,-200,vex::velocityUnits::rpm);
    Intake2.spin(vex::directionType::fwd,-200,vex::velocityUnits::rpm);

  }else {
    Intake1.stop();
    Intake2.stop();
  }

  if(controlButton('A', true)){
    if(slowmode){
      multiplier = normMult;
    }else {
      multiplier = slowMult;
    }

    slowmode = !slowmode;

  }

  driveLoop();
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Set up callbacks for autonomous and driver control periods.
  
  //Competition.autonomous(autonomous);
  Competition.drivercontrol(driveLoop);

  // Run the pre-autonomous function.

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);  initialize();

  }
}
